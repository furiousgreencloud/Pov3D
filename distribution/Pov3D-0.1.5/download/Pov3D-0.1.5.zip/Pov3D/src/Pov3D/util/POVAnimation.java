package Pov3D.util;
 
public abstract class POVAnimation extends POVObject {

	public abstract void setup();
	public abstract void update();
	public abstract void draw();
	public abstract void keyPressed();
	
}
