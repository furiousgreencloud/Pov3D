package Pov3D.util;

import processing.core.PApplet;

public class ProcessingObject {

	public static PApplet pApplet;
	
	public static void setPApplet(PApplet app) {
		ProcessingObject.pApplet = app;
	}
}
